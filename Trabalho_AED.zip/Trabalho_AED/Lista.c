#include <stdio.h>
#include <stdlib.h>
#include "Lista.h"

struct descritor
{
    int tamanho;
    struct no *inicio;
    struct no *fim;
};

int insertion_iterativo_crescente (int *vet, int N)
{
    int swap = 0;

    for (int i=1; i<N; i++)
    {
        int temp, j = i;
        temp = vet[j];
        while (j > 0 && temp < vet[j-1])
        {
            vet[j] = vet[j-1];
            j--;
            swap++;
        }
        vet[j] = temp;
    }
    return swap;
}

int insertion_iterativo_decrescente (int *vet, int N)
{
    int swap = 0;

    for (int i=1; i<N; i++)
    {
        int temp, j = i;
        temp = vet[j];
        while (j > 0 && temp > vet[j-1])
        {
            vet[j] = vet[j-1];
            j--;
            swap++;
        }
        vet[j] = temp;
    }
    return swap;
}


Lista* cria_lista ()
{
    Lista *l = malloc (sizeof (Lista));
    if (l != NULL)
    {
        l->inicio = NULL;
        l->fim = NULL;
        l->tamanho = 0;
        
        return l;
    }
    else return NULL;
}

void destroi_lista (Lista *l)
{
    if (l != NULL)
    {
        No *aux;
        while ((l->inicio) != NULL)
        {
            aux = l->inicio;
            l->inicio = aux->prox;
            free (aux);
        }
        free (l);
    }
    else exit(1);
}

int push (Lista *l, int num)
{
    if (l != NULL)
    {
        No *ponto = malloc (sizeof (No));
        // Erro de alocação
        if (ponto == NULL) return 0;

        ponto->x = num;
        ponto->prox = NULL;
        // Insere no inicio
        if (l->inicio == NULL) l->inicio = ponto;
        // Insere no fim
        else l->fim->prox = ponto;

        l->fim = ponto;
        l->tamanho++;
        return 1;
    }
    else exit(1);
}

int pop (Lista *l, int num)
{
    if (l != NULL)
    {
        // Não existe nó na lista
        if (l->inicio == NULL) return 0;
        No *remove = l->inicio;

        // Remove no inicio
        if (remove->x == num)
        {
            l->inicio = remove->prox;
            if (l->inicio == NULL) l->fim = NULL;
        }
        // Remove no meio ou no fim
        else
        {
            No *anterior;

            while (remove->x != num && remove->prox != NULL)
            {
                anterior = remove;
                remove = remove->prox;
            }
            // Nó está no meio da lista
            if (remove->prox != NULL) anterior->prox = remove->prox;
            // Nó está no fim da lista
            else
            {
                // Verifica se a 1ª condição do while foi quebrada
                if (remove->x == num)
                {
                    anterior->prox = remove->prox;
                    l->fim = anterior;
                }
                else return -1;
            }
            free (remove);
            l->tamanho--;
            return 1;
        }
    }
    else exit(1);
}

int consulta (Lista *l, int num)
{
    if (l != NULL)
    {
        // Não existe nó na lista
        if (l->inicio == NULL) return -1;
        No *aux = l->inicio;
        int contador = 0;

        while (aux != NULL)
        {
            if (aux->x == num) contador++;
            aux = aux->prox;
        }

        return contador;
    }
    else exit(1);
}

void imprime (Lista *l)
{
    if (l != NULL)
    {
        // Não existe nó na lista
        if (l->inicio == NULL) return;
        No *aux = l->inicio;

        printf ("\n=================================\n");
        while (aux != NULL)
        {
            printf ("%d ", aux->x);
            aux = aux->prox;
        }
        printf ("\n=================================\n");
    }
    else exit(1);
}

void sortCrescente (Lista *l, int *vet)
{
    int swap;
    if (l == NULL) exit(1);

    swap = insertion_iterativo_crescente (vet, l->tamanho);

    No *aux = l->inicio;
    int i = 0;

    while (aux != l->fim->prox)
    {
        aux->x = vet[i];
        aux = aux->prox;
        i++;
    }

    printf ("Lista DEPOIS da ordenacao:\n");
    imprime (l);
    printf ("Numero de trocas: %d\n", swap);
}

void sortDecrescente (Lista *l, int *vet)
{
    int swap;
    if (l == NULL) exit(1);

    swap = insertion_iterativo_decrescente (vet, l->tamanho);

    No *aux = l->inicio;
    int i = 0;

    while (aux != l->fim->prox)
    {
        aux->x = vet[i];
        aux = aux->prox;
        i++;
    }

    printf ("Lista DEPOIS da ordenacao:\n");
    imprime (l);
    printf ("Numero de trocas: %d\n", swap);
}