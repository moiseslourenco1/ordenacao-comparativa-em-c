typedef struct descritor Lista;

typedef struct no
{
    int x;
    struct no *prox;
} No;

Lista* cria_lista ();

void destroi_lista (Lista *l);

int push (Lista *l, int num);

int pop (Lista *l, int num);

int consulta (Lista *l, int num);

void imprime (Lista *l);

void sortCrescente (Lista *l, int *vet);

void sortDecrescente (Lista *l, int *vet);