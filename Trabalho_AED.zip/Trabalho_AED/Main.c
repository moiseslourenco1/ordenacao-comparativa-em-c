#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Lista.h"

void menu ();
void vetor_random (int *vet, int tamanho);

int main ()
{
    menu();

    return 0;
}

void menu ()
{
    int escolha, dado, result;
    int vetor[10];
    Lista *lista;

    do
    {
        printf ("\n==== MENU ====\n");
        printf ("1. Criar Lista\n2. Criar Numeros Randomicamente na Lista\n3. Retirar da Lista\n4. Consultar Elemento da Lista\n5. Ordena Crescente Lista\n6. Ordena Decrescente Lista\n7. Imprime Lista\n0. Sair\n\n");
        printf ("Bem-vindo! Escolha uma opcao para comercarmos: ");
        scanf ("%d", &escolha);

        switch (escolha)
        {
            case 1:
            lista = cria_lista ();
            if (lista) printf ("** Criacao bem sucedida! **\n");
            else printf ("** Erro de alocacao! **\n");
            break;

            case 2:
            vetor_random (vetor, 10);
            for (int i=0; i<10; i++)
                push (lista, vetor[i]);
            printf ("** Lista randomica criada com sucesso! **\n");
            break;

            case 3:
            printf ("Insira um numero para retirar da lista: %d");
            scanf ("%d", &dado);
            result = pop (lista, dado);
            if (result == 1) printf ("** Remocao bem sucedida! **\n");
            else if (result == -1) printf ("** Elemento nao existe na lista! **\n");
            else printf ("** Erro de alocacao! **\n");
            break;

            case 4:
            printf ("Insira um numero para consultar na lista: %d");
            scanf ("%d", &dado);
            result = consulta (lista, dado);
            if (result == -1) printf ("Nao existe no na lista! **");
            else printf ("** Elemento encontrado %d vez(es) na lista! **\n", result);

            case 5:
            sortCrescente (lista, vetor);
            break;

            case 6:
            sortDecrescente (lista, vetor);
            break;

            case 7:
            imprime (lista);

            case 0:
            destroi_lista (lista);
            break;
        }

    } while (escolha != 0);
}

void vetor_random (int *vet, int tamanho)
{
    srand(time(NULL));
    for (int i=0; i<tamanho; i++)
        vet[i] = rand();
}